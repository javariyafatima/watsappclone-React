import React from "react"


export default   function ErrorPage  (props) {
return(
    <>
    <div>
        error 404
    </div>
    </>
)
}